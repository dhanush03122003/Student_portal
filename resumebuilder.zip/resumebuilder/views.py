import json
from django.shortcuts import render,redirect
from django.http import HttpResponse
from resumebuilder.models import Details,Fee_det,Student_det,Bus_payment,Room,Table,Store_att,Marks,Announcement,Quries
from .forms import UserForm,Std_det,Std_UserForm
from project import settings
from django.core.mail import *
import random
from datetime import datetime
import pytz
import requests
from django.urls import reverse
from django.contrib import messages
import time
import string
import pandas as pd
import multiprocessing
from django.core.cache import cache
from io import BytesIO
from django.template.loader import get_template
from django.utils import timezone

# from xhtml2pdf import pisa  
def time_to_string(time_obj):
    return time_obj.strftime('%H:%M:%S')


# Create your views here.
def create_fee_data(em1,feet = "NONE",BAL=320000,FEE_PAID =0,STATUS = 0,PROCESS = "captured no error"):
    time_zone = pytz.timezone('Asia/Kolkata')
    current_time = datetime.now(time_zone)
    time_string = current_time.strftime("%H:%M:%S")
    date_string = current_time.strftime("%d-%m-%Y")
    tr_id = generate_transaction_id()
    ter = current_time.strftime("%Y")+"-"+str(int(current_time.strftime("%Y"))+1)
    g=Fee_det.objects.create(term = ter,email=em1,Fee_type = feet,status =STATUS,bal = BAL,date = date_string,time = time_string,fee_paid =FEE_PAID,transac_id = tr_id,process = PROCESS)

def generate_transaction_id(length=12):
    num_caps = min(5, length)  # Maximum 5 uppercase letters
    num_numbers = length - num_caps  # The rest will be numbers

    letters = string.ascii_uppercase
    numbers = string.digits[1:]  # Exclude 0 (zero) from the numbers

    # Generate the first part with random uppercase letters
    first_part = ''.join(random.choice(letters) for _ in range(num_caps))

    # Generate the second part with numbers (exclude 0 at the beginning)
    second_part = ''.join(random.choice(numbers) for _ in range(num_numbers))

    # Combine the two parts and shuffle them to randomize the position of caps
    transaction_id = first_part + second_part
    transaction_id = ''.join(random.sample(transaction_id, len(transaction_id)))

    return transaction_id

def HOME(request):
    return render(request,'home.html')
def main_page(request,ID):
    g = Student_det.objects.get(id = ID)
    name = g.f_name
    name1= g.l_name
    em = g.email
    return render(request,'sloginhome.html',{'s_id': ID,'name':name,'name1':name1,'email':em,'g':g})
def dd(request):
    print("dfg")
    d=Details.objects.all()
    if request.method == "POST":
        print("kkk")
        g=UserForm(request.POST)
        try :
            g1=Details.objects.get(email = request.POST['email'])
            print("kuyya1")
            #return HttpResponse('<script>alert(\'Email already exist!\'); window.location.href = "http://127.0.0.1:8000/sd/"</script>')

            # return HttpResponse('<script>if (confirm("Email already exist! navigate to signin ?")) { window.location.href = "http://127.0.0.1:8000/sign-in/"; } else {  window.location.href = "http://127.0.0.1:8000/sd/"; } </script>')
            sign_in_url = "/sign-in"  # Replace with your logic
            sd_url = "/sd"  # Replace with your logic

            # Construct the full URLs dynamically
            full_sign_in_url = request.build_absolute_uri(sign_in_url)
            full_sd_url = request.build_absolute_uri(sd_url)

            return HttpResponse(f'<script>if (confirm("Email already exists! Navigate to sign-in?")) {{ window.location.href = "{full_sign_in_url}"; }} else {{ window.location.href = "{full_sd_url}"; }}</script>')
        except:
            print(g)
            if g.is_valid():
                g.save()
                print("kkkk1")
                create_fee_data(request.POST['email'])
                
                # return HttpResponse('<script>alert(\'User created successfully\'); window.location.href = "http://127.0.0.1:8000/home/"</script>')
                home_url = "/home/"  # Replace with your logic

                full_home_url = request.build_absolute_uri(home_url)

                return HttpResponse(f'<script>alert(\'User created successfully\'); window.location.href = "{full_home_url}";</script>')
                        
    g=UserForm()
    return render(request,'signup.html',{'k':g})
def dd2(request):
    if request.method == "POST":
        try:
             d=Student_det.objects.get(email=request.POST['em'])
             print("yess")
        except Student_det.DoesNotExist:
            print("noooo")
            d = None
            # return HttpResponse('<script>alert(\'Invalid email or password\'); window.location.href = "http://127.0.0.1:8000/sign-in/"</script>')

            create_account_url = "/sd/"  # Replace with your logic
            sign_in_url = "/sign-in/"  # Replace with your logic

            # Construct the full URLs dynamically
            full_create_account_url = request.build_absolute_uri(create_account_url)
            print()
            full_sign_in_url = request.build_absolute_uri(sign_in_url)
            return HttpResponse(f'<script>if (confirm("Invalid email. Want to create one?")) {{ window.location.href = "{full_create_account_url}"; }} else {{ window.location.href = "{full_sign_in_url}"; }}</script>')

        if(d and request.POST['ps']==d.pasw):
            return redirect('/main_potal/'+str(d.id))
            # return render(request,'sloginhome.html',{'s_id': d.id})
        else:
            # return HttpResponse('<script>alert(\'Invalid email or password\'); window.location.href = "http://127.0.0.1:8000/sign-in/"</script>')
            sign_in_url = "/sign-in/"  # Replace with your logic

            # Construct the full URL dynamically
            full_sign_in_url = request.build_absolute_uri(sign_in_url)

            return HttpResponse(f'<script>alert(\'Invalid email or password\'); window.location.href = "{full_sign_in_url}";</script>')
    return render(request,'signin.html')
def otppp(request):
    ggg=False
    print(request.method)
    if request.method == "POST":
        print("sendind")
        sndr=request.POST['em']
        print( Student_det.objects.get(email=sndr))
        print(sndr)
        try : 
            print("kuyyaa")
            Student_det.objects.get(email=sndr)
            print("kutyya")
            sbj="Otp validation"
            m=''.join(random.choices('0123456789', k=6))
            t=settings.EMAIL_HOST_USER
            b=send_mail(sbj,m,t,[sndr])
            ggg=True
            error_message = False
            return render(request,'otp2.html',{'otp_sent':m,'form_submit':ggg,'em_feed':sndr,'error_message': error_message})
        except : 
            error_message = "Invalid email"
            # return HttpResponse('<script>alert(\'Invalid email\'); window.location.href = "http://127.0.0.1:8000/otp-/"</script>')
            otp_url = "/otp-/"  # Replace with your logic

    # Construct the full URL dynamically
            full_otp_url = request.build_absolute_uri(otp_url)

            return HttpResponse(f'<script>alert(\'Invalid email\'); window.location.href = "{full_otp_url}";</script>')

    return render(request,'otp2.html',{'form_submit':ggg})
def change_pass(request,email,check):
    d=Student_det.objects.get(email=email)
    if request.method == "POST":
        print("insede post")
        if request.POST['ps1']== request.POST['ps2']:
            d=Student_det.objects.get(email=email)
            d.pasw = request.POST['ps2']
            d.save()
            print("passs done")
            if(check == '#124789?'):
                # return redirect('/main_potal/'+str(d.id))
                # return HttpResponse('<script>alert(\'Password updated successfully\'); window.location.href = "http://127.0.0.1:8000/main_potal/' + str(d.id) + '";</script>')
                user_id = d.id # Replace with your logic
                main_portal_url = f"/main_potal/{user_id}/"  # Replace with your logic

                # Construct the full URL dynamically
                full_main_portal_url = request.build_absolute_uri(main_portal_url)

                return HttpResponse(f'<script>alert(\'Password updated successfully\'); window.location.href = "{full_main_portal_url}";</script>')
            else:
                # return HttpResponse('<script>alert(\'Password updated succesfully\'); window.location.href = "http://127.0.0.1:8000/sign-in/"</script>')   
                sign_in_url = "/sign-in/"  # Replace with your logic
                full_sign_in_url = request.build_absolute_uri(sign_in_url)
                return HttpResponse(f'<script>alert(\'Password updated successfully\'); window.location.href = "{full_sign_in_url}";</script>')
        else:
            error_message = "Password mismatched"
            d=Student_det.objects.get(email=email)
            return render(request,'new_pass.html',{'check' : check , 'ID':d.id ,'error_message': error_message })
    return render(request,'new_pass.html',{'check' : check , 'ID':d.id })
def pay(request,ID):
    em = Student_det.objects.get(id=ID)
    i = Fee_det.objects.filter(email = em.email,Fee_type="Tuition fees")
    print(i[len(i)-1].email)
        
    if request.method == "POST":
        if(i[len(i)-1].bal - int(request.POST['amnt'])>=0 and int(request.POST['amnt'])>0):
            STATUS = 2 if i[len(i)-1].bal - int(request.POST['amnt']) ==0 else 1
            create_fee_data(i[len(i)-1].email,feet="Tuition fees",BAL = i[len(i)-1].bal - int(request.POST['amnt']), FEE_PAID=request.POST['amnt'],STATUS=STATUS)
            print("payment done")
            error_message = "Payment done"
            #return HttpResponse('<script>alert(\'Payment done\'); window.location.href = "http://127.0.0.1:8000/sign-in/"</script>')   

            #return render(request, 'signin.html', {'error_message': error_message})
            #redirect('/sign-in')
            em = Student_det.objects.get(id=ID)
            i = Fee_det.objects.filter(email = em.email)
            time.sleep(5)
            return redirect('/fee_history/'+str(ID))
            return render(request,'pay_fee.html',{'s_id': ID,'b':i[len(i)-1].bal,'pai':320000-i[len(i)-1].bal})

        else:
            error_message = "invalid amount"
            return render(request, 'pay_fee.html', {'error_message': error_message,'s_id': ID,'b':i[len(i)-1].bal,'pai':320000-i[len(i)-1].bal})
    print(i[len(i)-1].bal)
    return render(request,'pay_fee.html',{'s_id': ID,'b':i[len(i)-1].bal,'pai':320000-i[len(i)-1].bal})
def pay_history(request,ID):
    em = Student_det.objects.get(id=ID)
    i = Fee_det.objects.filter(email = em.email)
    i=list(i)
    i.pop(0)
    return render(request,'pay_fee_history.html',{'t':i})
def student_form(request):
    g=Std_det()
    if cache.get('csv_data') is None or cache.get('x') is None or cache.get('i2') is None :
       csv_data = pd.read_excel(r"C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\states-cities.xlsx")
       i = pd.read_excel(r"C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\Countries_States.xlsx")
       i= i.fillna(0)
       i2 = i.to_dict(orient='dict')
       i4 = csv_data.to_dict(orient='dict')
       x=json.dumps([i1 for i1 in i])
       cache.set('csv_data', i4 ,600)
       cache.set('i2',i2 ,600)
       cache.set('x',x , 600)


    corr = pd.read_excel(r"C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\courses.xlsx",header=None)
    corr= json.dumps(list(corr[0]))# 0 is a column headding
    if(request.method=='POST'):
        try :
            u1=Student_det.objects.get(email=request.POST['email'])
            error_message = "Email id already exist"
            return render(request,'st_form.html',{'form':g , 'names_var':corr,'error_message': error_message})
        except:
            u=Std_det(request.POST)
            if u.is_valid:
                u.save()
                u1=Student_det.objects.get(email=request.POST['email'])
                u1.course = request.POST['Cour']
                u1.branch = request.POST['sub_cor']
                u1.country = request.POST['country1']
                u1.state = request.POST['state1']
                u1.city = request.POST['city1']
                input_date = request.POST['dob']
                parsed_date = datetime.strptime(input_date, "%Y-%m-%d")
                formatted_date = parsed_date.strftime("%d-%m-%Y")
                u1.dob = formatted_date
                u1.pasw = formatted_date
                u1.save()
                sbj="Welcome to Srm University AP"
                file_content = open(r"C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\welcome_email.txt").read()
                file_content = file_content.replace("[Student's Name]",request.POST['f_name'])
                file_content = file_content.replace("MMMMM",request.POST['email'])
                file_content = file_content.replace("dd-mm-yyyy",formatted_date)
                m=file_content
                print(m)
                t=settings.EMAIL_HOST_USER

                b=send_mail(sbj,m,t,[request.POST['email']])
                # g1=Details.objects.create(email=request.POST['email'] , pasw = formatted_date)
                create_fee_data(request.POST['email'],feet="Tuition fees")
                stri = request.POST['Cour'] +"-"+ request.POST['sub_cor']
                k = Table.objects.filter(pasw = stri)############  09-09-2023
                for i in k:
                    Marks.objects.create(subj_code = i.subj_code,email = request.POST['email'],cla1 = 0,cla2 = 0,cla3 = 0,mid = 0,sem = 0)
                print("done!!!")
            
            
    return render(request,'st_form.html',{'form':g , 'names_var':corr,'ctry':cache.get('x'),'st':cache.get('i2'),'cty':cache.get('csv_data')})
# def std_pass_(request):
#     print("dfg")
#     d=Std_user_det.objects.all()
#     if request.method == "POST":
#         print("kkk")
#         g=Std_UserForm(request.POST)
#         try :
#             g1=Std_user_det.objects.get(email = request.POST['email'])
#             print("kuyya1")
#             #return HttpResponse('<script>alert(\'Email already exist!\'); window.location.href = "http://127.0.0.1:8000/sd/"</script>')
#             return HttpResponse('<script>if (confirm("Email already exist! navigate to signin ?")) { window.location.href = "http://127.0.0.1:8000/sign-in/"; } else {  window.location.href = "http://127.0.0.1:8000/sd/"; } </script>')
#         except:
#             print(g)
#             if g.is_valid():
#                 g.save()
#                 print("kkkk1")
#                 create_fee_data(request.POST['email'])
#                 return HttpResponse('<script>alert(\'User created successfully\'); window.location.href = "http://127.0.0.1:8000/home/"</script>')
                
#     g=Std_UserForm()
#     return render(request,'signup.html',{'k':g})

def bus_reg(request,ID):
    try :
        try:
            Bus_payment.objects.get(orj_id = ID)
        #    return HttpResponse('<script>alert("You had already registered for the transport"); window.location.href = "http://127.0.0.1:8000/main_potal/' + str(ID) + '";</script>')
            user_id = ID  # Replace with your logic
            full_portal_url = request.build_absolute_uri(f"/main_potal/{user_id}")
            return HttpResponse(f'<script>alert("You had already registered for the transport"); window.location.href = "{full_portal_url}";</script>')
        except:
            em = Student_det.objects.get(id = ID).email
            Fee_det.objects.get(email = em,status = 2,Fee_type ="Hostel Fees")
            # return HttpResponse('<script>alert("you can register either for transport or hostel at a time"); window.location.href = "http://127.0.0.1:8000/main_potal/' + str(ID) + '";</script>')
            user_id = ID  # Replace with your logic
            full_portal_url = request.build_absolute_uri(f"/main_potal/{user_id}/")
            return HttpResponse(f'<script>alert("you can register either for transport or hostel at a time"); window.location.href = "{full_portal_url}";</script>')
    except:

        i = pd.read_excel(r"C:\Users\ABHIGNA\Desktop\project\project\resumebuilder\busroutes.xlsx")

        # i['V1_time'] = [str(i) for i in i['V1_time']]
        # i['V2_time'] = [str(i) for i in i['V2_time']]
        # i['V3_time'] = [str(i) for i in i['V3_time']]
        bus_names = list(i['Bus_no'])
        for j in bus_names:
            stri = j+'_time'
            i[stri] = [str(i) for i in i[stri]]




        data_dict = i.to_dict(orient='dict')


        for i in data_dict:
            data_dict[i]=list(data_dict[i].values())
        if request.method == "POST":
            m1 = Student_det.objects.get(id = ID)
            m=''.join(random.choices('0123456789', k=7))
            route = request.POST['sel_place']
            num = request.POST['sel_bus_r']
            stop = request.POST['sel_stp']
            time_zone = pytz.timezone('Asia/Kolkata')
            current_time = datetime.now(time_zone)
            time_string = current_time.strftime("%H:%M:%S")
            date_string = current_time.strftime("%d-%m-%Y")
            # print(request.POST.keys()) 
            paid = int(request.POST['money'])
            Bus_payment.objects.create(orj_id = ID ,country =m1.country ,state =m1.state,city =m1.city , route =route,bus_no =num,bus_stop = stop,time = time_string,date = date_string , rec_id = m )
            create_fee_data(m1.email,feet ="Bus Fee",BAL = 0,FEE_PAID=paid,STATUS=2)
            # return redirect('/main_potal/'+str(d.id))
            # return HttpResponse('<script>alert("User created successfully"); window.location.href = "http://127.0.0.1:8000/main_potal/' + str(ID) + '";</script>')
            user_id = ID  # Replace with your logic
            full_portal_url = request.build_absolute_uri(f"/main_potal/{user_id}/")
            return HttpResponse(f'<script>alert("User created successfully"); window.location.href = "{full_portal_url}";</script>')

        return render(request,'bus_reg.html',{'data_dict':data_dict,'ID':ID})
# def first_program():
#     i3 = pd.read_excel(r'C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\states-cities.xlsx')


# def contry(request):
#     # process2 = multiprocessing.Process(target=second_program)
#     if cache.get('csv_data') is None:
#        csv_data = pd.read_excel(r'C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\states-cities.xlsx')
#        i4 = csv_data.to_dict(orient='dict')
#        cache.set('csv_data', i4)

#     i = pd.read_excel(r'C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\Countries_States.xlsx')
#     i= i.fillna(0)
#     x=json.dumps([i1 for i1 in i])
#     i2 = i.to_dict(orient='dict')
#     return render(request,'country_dis.html',{'ctry':x,'st':i2,'cty':cache.get('csv_data')})

def hostelmain(request,sid):
    try:
        em = Student_det.objects.get(id = sid).email
        Fee_det.objects.get(email = em,status = 2,Fee_type ="Bus Fee")
        
        # return HttpResponse('<script>alert("you can register either for transport or hostel at a time"); window.location.href = "http://127.0.0.1:8000/main_potal/' + str(sid) + '";</script>')
        # sid = 123  # Replace with your logic
        # Construct the full URL dynamically
        full_portal_url = request.build_absolute_uri(f"/main_potal/{sid}/")

        return HttpResponse(f'<script>alert("you can register either for transport or hostel at a time"); window.location.href = "{full_portal_url}";</script>')
    except:
            rooms=Room.objects.all()
            #crate(request)
            for room in rooms:
                if room.room_type=='AC' and room.sharing_type==2:
                    room.fee=165000
                if room.room_type=='AC' and room.sharing_type==3:
                    room.fee=155000
                if room.room_type=='AC' and room.sharing_type==4:
                    room.fee=145000
                if room.room_type=='AC' and room.sharing_type==5:
                    room.fee=135000
                if room.room_type=='NONAC' and room.sharing_type==2:
                    room.fee=100000
                if room.room_type=='NONAC' and room.sharing_type==3:
                    room.fee=90000
                if room.room_type=='NONAC' and room.sharing_type==4:
                    room.fee=80000
                if room.room_type=='NONAC' and room.sharing_type==5:
                    room.fee=70000
                room.save()

            str1=[]
            em=Student_det.objects.get(id=sid).email
            t1rooms=Room.objects.filter(tower_num=1)
            t2rooms=Room.objects.filter(tower_num=2)
            t3rooms=Room.objects.filter(tower_num=3)
            t4rooms=Room.objects.filter(tower_num=4)
            
            t1v=0
            t2v=0 
            t3v=0 
            t4v=0 
            t1ravble=0 
            t2ravble=0 
            t3ravble=0 
            t4ravble=0 
            for room in t1rooms:
                t1v+=room.vacancies
                if room.occupied!=room.sharing_type:
                    t1ravble+=1
            for room in t2rooms:
                t2v+=room.vacancies
                if room.occupied!=room.sharing_type:
                    t2ravble+=1
            for room in t3rooms:
                t3v+=room.vacancies
                if room.occupied!=room.sharing_type:
                    t3ravble+=1
            for room in t4rooms:
                t4v+=room.vacancies
                if room.occupied!=room.sharing_type:
                    t4ravble+=1
            print("t1 vac",t1v)
            print("t1 rooms",t1ravble)
            print("t2 vac",t2v)
            print("t2 rooms",t2ravble)
            print(t2rooms)
            for i in range(1,101):
                str1.append(Room.objects.get(id=i).email1)
                str1.append(Room.objects.get(id=i).email2)
                str1.append(Room.objects.get(id=i).email3)
                str1.append(Room.objects.get(id=i).email4)
                str1.append(Room.objects.get(id=i).email5)
            if em in str1:
                print('already existes')
                full_portal_url = request.build_absolute_uri(f"/main_potal/{sid}")

                return HttpResponse(f'<script>alert("You have already registered for the hostel room."); window.location.href = "{full_portal_url}";</script>')
            else:
                st=Student_det.objects.get(id=sid)
                if st.gender=='Female':
                    return render(request,'hostelmain.html',{'sid':sid,'t1v':t1v,'t2v':t2v,'t1ravble':t1ravble,'t2ravble':t2ravble})
                else:
                    return render(request,'hostelmain.html',{'sid':sid,'t3v':t3v,'t4v':t4v,'t3ravble':t3ravble,'t4ravble':t4ravble})
def hostelroom(request,id,tno):
    rooms=Room.objects.filter(tower_num=tno)
    floor_numbers = set(room.floor_num for room in rooms)
    return render(request,'hostelroom.html',{'rooms':rooms,'id':id,'tno':tno,'floor_numbers': floor_numbers,})

def booking(request,id1,tno,num):
    room=Room.objects.get(room_number=num,tower_num=tno)
    em1=Student_det.objects.get(id=id1).email
    if request.method=="POST":
        print('hhhhhhhhhhhhhhh')
        room=Room.objects.get(room_number=num,tower_num=tno)
        if room.occupied==0:
            room.email1=Student_det.objects.get(id=id1).email
        elif room.occupied==1:
            room.email2=Student_det.objects.get(id=id1).email
        elif room.occupied==2:
            room.email3=Student_det.objects.get(id=id1).email
        elif room.occupied==3:
            room.email4=Student_det.objects.get(id=id1).email
        elif room.occupied==4:
            room.email5=Student_det.objects.get(id=id1).email
        room.occupied+=1
        
        room.save()
        create_fee_data(em1,feet = "Hostel Fees",BAL=0,FEE_PAID =room.fee,STATUS = 2)
        #pdf generation
        return redirect('/main_potal/'+str(id1))
    return render(request,'hostelbooking.html',{'room':room,'id1':id1})

def crate(request):
    count = 0
    count1 = 0
    tow=1
    room_sh = [2,3,4,4,5]
    gw=1
    room =[101,201,301,401,501]
    for i in range(1,101):
        if(count==5):
            count=0
            count1 = count1 +1
        if(count1==5):
            count1=0
        s = ""
        if i %2==0:
            s="AC"
        else:
            s="NONAC"
        if i==26 or i==51 or i==76:
            tow = tow+1
        if i % 6 ==0:
            gw+=1
        if gw == 6:
            gw=1
        Room.objects.create(email1="",email2="",email3="",email4="",email5="",room_number=room[count1]+count,tower_num=tow,floor_num=(room[count1]+count)//100,room_type=s,sharing_type=room_sh[count],occupied=0)
        count = count+1

def cancel(request,ID,bal,strr):
    em = Student_det.objects.get(id = ID).email
    create_fee_data(em1= em,BAL = bal,PROCESS="User cancelled",feet=strr)
    return redirect('/main_potal/'+str(ID))
    return HttpResponse('<script>alert(\'Password updated succesfully\')); window.location.href = "http://127.0.0.1:8000/main_potal/' + str(ID) + '";</script>')

def busack(request,id):
    try:
        g=Bus_payment.objects.get(orj_id = id)
        s=Student_det.objects.get(id=id)
        em=s.email
        g1=Fee_det.objects.get(email=em,Fee_type="Bus Fee",process="captured no error")
        reg=True
        return render(request,'busack.html',{'g':g,'g1':g1,'reg':reg,'s':s})
    except:
        reg=False
        return render(request,'busack.html',{'reg':reg})

# def html_to_pdf(template_src, context_dict={}):
#      template = get_template(template_src)
#      html  = template.render(context_dict)
#      result = BytesIO()
#      pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
#      if not pdf.err:
#          return HttpResponse(result.getvalue(), content_type='application/pdf')
#      return None

def hostel_ack(request,id):
    try:
        print(11111)
        s=Student_det.objects.get(id=id)
        st=s.email
        print(2222)
        # g=Room.objects.filter(occupied>0)
        g = Room.objects.filter(occupied__gt=0)

        print(333)
        print(g)
        for i in range(len(g)):
            id1=g[i].id
            lis=[]
            if st==g[i].email1:
                id2=id1
                break
            if st==g[i].email2:
                id2=id1
                break
            if st==g[i].email3:
                id2=id1
                break
            if st==g[i].email4:
                id2=id1
                break
            if st==g[i].email5:
                id2=id1
                break
        g=Room.objects.get(id=id2)
        g1=Fee_det.objects.get(email=st,Fee_type="Hostel Fees",process="captured no error")
        reg=True
        return render(request,'hostelack.html',{'g':g,'g1':g1,'reg':reg,'s':s})
    except:
        reg=False
        return render(request,'hostelack.html',{'reg':reg})
def fee_ack(request,id):
    try:
        s=Student_det.objects.get(id=id)
        em=s.email
        g=Fee_det.objects.filter(email=em,Fee_type="Tuition fees",process="captured no error",fee_paid__gt=0)
        balance=g[len(g)-1].bal
        paid=320000-balance
        reg=True
        return render(request,'fee_ack.html',{'g':g,'reg':reg,'s':s,'balance':balance,'paid':paid})
    except:
        reg=False
        return render(request,'fee_ack.html',{'reg':reg})
def import_teacher_data_from_csv(csv_file_path = r"C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\teachers_data.csv"):
    if not Table.objects.exists():
        df = pd.read_csv(csv_file_path, na_values=[''], keep_default_na=False)

        # Convert NaN to None and handle password column
        df['pasword'] = df['pasword'].apply(lambda x: str(x) if not pd.isna(x) else '')
        df['user_id'] = df['user_id'].apply(lambda x: str(x) if not pd.isna(x) else '')

        for _, row in df.iterrows():
            _, created = Table.objects.get_or_create(**row.to_dict())
        print("Data imported successfully.")
    else:
        print("Table is not empty. Skipping import.")
def attendance(request,c_id):
    

    # data = [
    #     {"subj_code": "MAT-103", "pasw": "B.Tech-CSE", "p1": "1,1", "p2": "1,2", "p3": "3,1"},
    #     {"subj_code": "CSE-103", "pasw": "B.Tech-CSE", "p1": "2,2", "p2": "2,3", "p3": "5,8"},
    #     {"subj_code": "ENG-102", "pasw": "B.Tech-CSE", "p1": "1,5", "p2": "1,6", "p3": "2,1"},
    #     {"subj_code": "APT-101", "pasw": "B.Tech-CSE", "p1": "4,7", "p2": "5,1", "p3": "5,2"},
    #     {"subj_code": "CSEL-101", "pasw": "B.Tech-CSE", "p1": "3,2", "p2": "3,3", "p3": "-1,-1"},
    #     {"subj_code": "ENV-103", "pasw": "B.Tech-CSE", "p1": "2,7", "p2": "4,5", "p3": "4,6"},
    #     {"subj_code": "EEE-103", "pasw": "B.Tech-CSE", "p1": "1,8", "p2": "4,8", "p3": "5,5"},
    # ]

    # for entry in data:
    #   Table.objects.create(**entry)

    # branch = "CSE"
    # course = "B.Tech"
    import_teacher_data_from_csv()
    course_id = c_id
    g=Table.objects.get(subj_code = course_id)
    g = g.pasw
    # print(g)
    g=g.split("-")
    print(g)
    g1 = Student_det.objects.filter(course =g[0],branch =g[1])
    g1_json = json.dumps(list(g1.values()))
    # print(g1)
    if request.method == 'POST':
        # print(list(request.POST.keys())[1:])
        print(request.POST.getlist('selected_rows'))
        lis = list(request.POST.getlist('selected_rows'))
        lis = lis[0].split(",")
        # print()
        create_attend(lis,course_id)
        return render(request,'attend.html',{'g1_json': g1_json, 'num_checkboxes' : len(g1)})
    return render(request,'attend.html',{'g1_json': g1_json, 'num_checkboxes' : len(g1)})
def create_attend(lis,course_id):
    time_zone = pytz.timezone('Asia/Kolkata')
    current_time = datetime.now(time_zone)
    time_string = current_time.strftime("%H:%M:%S")
    date_string = current_time.strftime("%d-%m-%Y")
    Store_att.objects.filter(date=date_string , subj_code = course_id ).delete()
    for i in lis:
        Store_att.objects.create(date = date_string,time = time_string,orj_id = i,subj_code = course_id)
def pass_sub_details(request,c_id):

    #course_id = "ENV-103"
    course_id=c_id
    g=Table.objects.get(subj_code = course_id)
    r=[]
    c=[]
    r.append(int(g.p1.split(",")[0])),c.append(int(g.p1.split(",")[1])) 
    r.append(int(g.p2.split(",")[0])),c.append(int(g.p2.split(",")[1]))
    if int(g.p3.split(",")[0])!=-1:
        r.append(int(g.p3.split(",")[0])),c.append(int(g.p3.split(",")[1]))

    list1=json.dumps(r)
    list2=json.dumps(c)
    # print(row,col)
    time_zone = pytz.timezone('Asia/Kolkata')
    current_time = datetime.now(time_zone)
    time_string = current_time.strftime("%H:%M:%S")
    date_string = current_time.strftime("%d-%m-%Y")
    # list1 = [1, 2, 3, 4, 5]
    # list2 = [10, 20, 30, 40, 50]
    print(list1,list2)
    url = reverse('att', args=[course_id])
    current_date = timezone.now()

    # Extract the current day as an integer (1 for Monday, 2 for Tuesday, etc.)
    current_day = current_date.weekday() + 1  # Adding 1 to match 1-based indexing

    return render(request,'timetable.html',{'c_id':course_id,'course_id':course_id,'list1': list1,
        'list2': list2,'g':g,'url':url,'day':current_day})

def ad_login(request):

    return render(request,'adminlogin.html')

def flogin(request):
    import_teacher_data_from_csv()
    if request.method == 'POST':
        try:
            g=Table.objects.get(user_id = request.POST['username'])
            print('hihi')
            print(g.subj_code)
        except:
            # return HttpResponse('<script>alert("Invalid email or password!"); window.location.href = "http://127.0.0.1:8000/flogin/";</script>')
            login_url = "/flogin/"  # Replace with your logic
            full_login_url = request.build_absolute_uri(login_url)
            return HttpResponse(f'<script>alert("Invalid email or password!"); window.location.href = "{full_login_url}";</script>')
        
        if request.POST['pw'] == g.pasword:
            # return HttpResponse('<script>window.location.href = "http://127.0.0.1:8000/Faculty/' +g.subj_code+'";</script>')
            full_subject_url = request.build_absolute_uri(f"/Faculty/{g.subj_code}/")
            return HttpResponse(f'<script>window.location.href = "{full_subject_url}";</script>')
        else:
            # return HttpResponse('<script>alert("Invalid email or password!"); window.location.href = "http://127.0.0.1:8000/flogin/";</script>')
            login_url = "/flogin/"  # Replace with your logic
            full_login_url = request.build_absolute_uri(login_url)
            return HttpResponse(f'<script>alert("Invalid email or password!"); window.location.href = "{full_login_url}";</script>')

             
    return render(request,'facultylogin.html')

def f_login_home(request,c_id):
    url = reverse('disp_tt', args=[c_id])
    return render(request,'faculty_login_home.html',{'c_id':c_id,'url':url})

def count_weekdays(start_date, end_date):
    import datetime
    weekdays_count = {
        '1': 0,  # Monday
        '2': 0,  # Tuesday
        '3': 0,  # Wednesday
        '4': 0,  # Thursday
        '5': 0   # Friday
    }

    current_date = start_date
    while current_date <= end_date:
        day_of_week = current_date.weekday()  # Get the day of the week as an integer (0 = Monday, 1 = Tuesday, ...)
        day_str = str(day_of_week + 1)  # Convert the integer to a string (1, 2, 3, 4, 5)
        if day_str in weekdays_count:
            weekdays_count[day_str] += 1
        current_date += datetime.timedelta(days=1)

    return weekdays_count

def calc_att(subj,sid):
    g=Store_att.objects.filter(orj_id=sid,subj_code=subj)
    days={}
    g1=Table.objects.get(subj_code=subj)
    if g1.p1.split(',')[0] in days:
        days[g1.p1.split(',')[0]]+=1
    else:
        days[g1.p1.split(',')[0]]=1
    if g1.p2.split(',')[0] in days:
        days[g1.p2.split(',')[0]]+=1
    else:
        days[g1.p2.split(',')[0]]=1
    if g1.p3.split(',')[0] in days and g1.p3.split(',')[0]!='-1':
        days[g1.p3.split(',')[0]]+=1
    else:
        if g1.p3.split(',')[0]!='-1':
            days[g1.p3.split(',')[0]]=1
    return days,g

def stu_att(request,sid):
    import datetime
    s=Student_det.objects.get(id=sid)
    c=s.course
    b=s.branch
    str1=c+"-"+b 
    g2=Table.objects.filter(pasw=str1)
    subj_list=[]
    dic={}
    for i in g2:
        subj_list.append(i.subj_code)
    for i in subj_list:
        days,g=calc_att(i,sid)
        start_date = datetime.date(2023, 9, 2)  # Corrected the year to 20023
        end_date = datetime.date.today()

        weekday_counts = count_weekdays(start_date, end_date)
        print(weekday_counts)
        print(days)
        total_hrs=0 
        for key in days:
            if key in weekday_counts:
                total_hrs+=days[key]*weekday_counts[key]
        print(total_hrs)
        present_hrs=len(g)
        absent_hrs=total_hrs-present_hrs
        pre_perc=(present_hrs/total_hrs)*100
        pre_perc=round(pre_perc,2)
        print(present_hrs,absent_hrs,pre_perc)
        dic[i]=[total_hrs,present_hrs,absent_hrs,pre_perc]
    print(dic)
    return render(request,"studentattendance.html",{'dic':dic})

def student_internals(request,c_id):
    # c_id = "MAT-103"
    roll_nos = []
    names = []
    students = Marks.objects.filter(subj_code = c_id) 
    for i in students:
        g = Student_det.objects.get(email = i.email)
        roll_nos.append(g.r_no)
        nm = g.f_name +" "+ g.l_name
        names.append(nm)
    student_data = []
    for student, roll_no, name in zip(students, roll_nos, names):
        student_dict = {
            'roll_no': roll_no,
            'name': name,
            'email': student.email,
            'cla1': student.cla1,
            'cla2': student.cla2,
            'cla3': student.cla3,
            'mid': student.mid,
        }
        student_data.append(student_dict)


    print(students)
    print(student_data)
    # Query the database for saved records
    if request.method == 'POST':
            print(request.POST)
            for index, student in enumerate(students):
                student.cla1 = request.POST.get(f'cla1_{index}')
                student.cla2 = request.POST.get(f'cla2_{index}')
                student.cla3 = request.POST.get(f'cla3_{index}')
                student.mid = request.POST.get(f'mid_{index}')
                student.save()
            
            student_data = []
            for student, roll_no, name in zip(students, roll_nos, names):
                student_dict = {
                    'roll_no': roll_no,
                    'name': name,
                    'email': student.email,
                    'cla1': student.cla1,
                    'cla2': student.cla2,
                    'cla3': student.cla3,
                    'mid': student.mid,
                }
                student_data.append(student_dict)
            return render(request, 'internal_marks.html', { 'students':student_data,'c_id':c_id})
                    
    return render(request, 'internal_marks.html', { 'students':student_data,'c_id':c_id})
def student_endsem(request,c_id):
    # c_id = "MAT-103"
    roll_nos = []
    names = []
    students = Marks.objects.filter(subj_code = c_id) 
    for i in students:
        g = Student_det.objects.get(email = i.email)
        roll_nos.append(g.r_no)
        nm = g.f_name +" "+ g.l_name
        names.append(nm)
    print(names)
    student_data = []
    for student, roll_no, name in zip(students, roll_nos, names):
        student_dict = {
            'roll_no': roll_no,
            'name': name,
            'email': student.email,
            'sem' : student.sem,
        }
        student_data.append(student_dict)    
    if request.method == 'POST':
        print(request.POST)
        for index, student in enumerate(students):
            student.sem = request.POST.get(f'sem_{index}')
            student.save()
        
        student_data = []
        for student, roll_no, name in zip(students, roll_nos, names):
            student_dict = {
                'roll_no': roll_no,
                'name': name,
                'email': student.email,
                'sem' : student.sem,
            }
            student_data.append(student_dict)
        return render(request, 'endsem_marks.html', {'students':student_data,'c_id':c_id})
    return render(request, 'endsem_marks.html', {'students':student_data,'c_id':c_id})

def internals_display(request,s_id):
    em=Student_det.objects.get(id=s_id).email
    print(em)
    marks_data=Marks.objects.filter(email=em)
    print(marks_data)
    d={}
    for i in marks_data:
        d[i.subj_code]=[i.cla1+i.cla2+i.cla3+i.mid,i.cla1,i.cla2,i.cla3,i.mid]
    print(d)
    return render(request,'student_int_marks.html',{'d':d})

def adminhome(request):
    return render(request,'adminhome.html')

def announcements(request):
    if request.method=="POST":
        print(request.POST)
        title = request.POST['title']
        image = request.FILES['image1']
        body = request.POST['body']
        
        # Create and save the Announcement object
        announcement = Announcement(title=title,image=image,  body=body)
        announcement.save()
        return render(request,'admin-announcements.html')
    return render(request,'admin-announcements.html')

def da(request):
    announcements = Announcement.objects.all()
    return render(request, 'da.html', {'announcements': announcements})

def cal_sgpa(request,s_id):
    g=Table.objects.all()
    if(len(g)==0):
        #excel_file_path = "C:\Users\DHANUSH\Desktop\djanggo\project\resumebuilder\resumebuilder_table.csv"
        df =  pd.read_csv(r"C:\Users\ABHIGNA\Desktop\project\project\resumebuilder\resumebuilder_table.csv")
        for index, row in df.iterrows():
                Table.objects.create(
                subj_code=row['subj_code'],
                pasw=row['pasw'],
                p1=row['p1'],
                p2=row['p2'],
                p3=row['p3'],
                name = row['name'],
                subj_name = row['subj_name'])
    em=Student_det.objects.get(id=s_id).email
    g = Marks.objects.filter(email = em)
    credits = []
    mark_dict = {}
    for i in g:
        credits.append(int(i.subj_code[-1]))
        mark_dict[i.subj_code] = int(i.cla1)+int(i.cla2)+int(i.cla3)+int(i.mid)+(int(i.sem)/2)
    mark_grade_dict = {}
    for keys, values in mark_dict.items():
        mark_grade_dict[keys] = cal_grade(keys,values)
    mark_grade_dict_number = {}
    grade_pt = {
        'O':10,
        'A+':9,
        'A':8,
        'B+':7,
        'B':6,
        'C':5,
        'F':0
    }
    for keys, values in mark_grade_dict.items():
         mark_grade_dict_number[keys] = grade_pt[values]
    print(mark_grade_dict_number.values()) #points
    print(mark_grade_dict_number.keys()) #subj codes
    print(mark_grade_dict.values()) #grades
    print(mark_dict)
    print(credits)
    s = [i*j for i,j in zip(credits,mark_grade_dict_number.values())]
    print(sum(s)/sum(credits)) #sgpa
    sgpa=sum(s)/sum(credits)
    subj_names=[]
    for i in mark_grade_dict_number.keys():
        subj_names.append(Table.objects.get(subj_code=i).subj_name)
    combined_data = []
    l = ['PASS' if value != 'F' else 'FAIL' for value in mark_grade_dict.values()]

    mark_grade_dict_number_keys = list(mark_grade_dict_number.keys())
    index=0 
    for credit,j,k in zip(credits,subj_names,l):
        subj_code = mark_grade_dict_number_keys[index]
        combined_data.append({
            'subj_code': subj_code,
            'credit': credit,
            'subj_name':j,
            'points': mark_grade_dict_number[subj_code],
            'grade': mark_grade_dict.get(subj_code, ''),
            'result':k

        })
        index+=1
    return render(request,'gpa.html',{'combined_data': combined_data,'sgpa':sgpa})

def cal_grade(c_id,subj_mark):
    g = Marks.objects.filter(subj_code = c_id)
    all_marks = []
    for i in g:
        all_marks.append(int(i.cla1)+int(i.cla2)+int(i.cla3)+int(i.mid)+(int(i.sem)/2))
    target_mark = subj_mark
    percentile = calculate_percentile_rank(all_marks,target_mark)
    Grade = ""
    for grade, percentile_threshold in [('O', 90), ('A+', 80), ('A', 70), ('B+', 60), ('B', 50), ('C', 40), ('F', 0)]:
        if  percentile >= percentile_threshold:
            Grade = grade
            print(f"Grade for {target_mark} marks: {grade}")
            break
    return Grade
def calculate_percentile_rank(marks, student_mark):
    count = 0
    total = len(marks)
    
    for mark in marks:
        if mark <= student_mark:
            count += 1

    percentile_rank = (count / total) * 100
    return percentile_rank

def teacher_side(request,c_id):
    #c_id = "MAT-103"
    g = Quries.objects.filter(reciever = c_id,enq_id=0)
    total_data = []
    for i in g:
        data={}
        data['text']=i.text
        data['subject']=i.subject
        data['roll_no']=Student_det.objects.get(email = i.sender).r_no
        data['name']=Student_det.objects.get(email = i.sender).f_name + " "+ Student_det.objects.get(email = i.sender).l_name
        data['email']=i.sender
        data['id'] = i.id
        total_data.append(data)
    if request.method =="POST":
        print(request.POST)
        ID =  list(request.POST.keys())[1]
        txt =  request.POST[list(request.POST.keys())[1]]  
        em = Quries.objects.get(id = int(ID)).sender
        subj = Quries.objects.get(id = int(ID)).subject
        tchr_name = Table.objects.get(subj_code = c_id).name
        t=settings.EMAIL_HOST_USER
        print(em)
        txt = "Dear Student,\n\n I had looked into your query.\n"+txt +"\n\nRegards,\n"+tchr_name
        sndr = "dhanu03@gmail.com"
        send_mail(subj,txt,t,[em])
            
            # email_1 = EmailMessage(subj, txt, t, [em])
            # email_1.send()

        q1=Quries.objects.get(id = int(ID))
        q1.enq_id=1
        q1.save()


 

    return render(request,'recieved_quri.html',{'g':total_data,'c_id':c_id})


def create_qur(request,s_id):
    #s_id = 1

    g=Student_det.objects.get(id=s_id)
    em = g.email
    g2 = None
    try:
        g2 = Quries.objects.filter(sender = em)
    except:
        pass
    sender = em
    stri = g.course+"-"+g.branch
    g1 = Table.objects.filter(pasw = stri)
    teacher_lis = []
    for i in g1:
        teacher_lis.append(i.subj_code)
    x=teacher_lis
    d=[]
    for i in g2:
        dic={}
        dic['subject']=i.subject
        dic['reciever']=i.reciever
        dic['text']=i.text
        dic['enq_id']=i.enq_id
        dic['time']=i.date+"    "+i.time
        if i.reciever!='ADMIN':
            k=Table.objects.get(subj_code=i.reciever).name
            dic['name']=k

        d.append(dic)
    if request.method == "POST":
        stri = request.POST['txt']
        stri1 = request.POST['subj-txt']
        print(request.POST)
        reciever = None
        try:
            reciever = request.POST['reciever1']
        except:
            reciever = request.POST['reciever']
        time_zone = pytz.timezone('Asia/Kolkata')
        current_time = datetime.now(time_zone)
        time_string = current_time.strftime("%H:%M:%S")
        date_string = current_time.strftime("%d-%m-%Y")
        g = Quries.objects.create(subject =stri1, text = stri,sender = sender,reciever =reciever,time = time_string,date = date_string,enq_id = 0)
        try:
            g2 = Quries.objects.filter(sender = em)
        except:
            pass
            d=[]
        for i in g2:
            dic={}
            dic['subject']=i.subject
            dic['reciever']=i.reciever
            dic['text']=i.text
            dic['enq_id']=i.enq_id
            dic['time']=i.date+"    "+i.time
            if i.reciever!='ADMIN':
                k=Table.objects.get(subj_code=i.reciever).name
                dic['name']=k

            d.append(dic)
        return render(request,'create_quri.html',{'lis':x,'g2':d})

        
    return render(request,'create_quri.html',{'lis':x,'g2':d})