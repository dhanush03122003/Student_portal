from .models import Details
from .models import Student_det,Bus_payment
from django import forms


class UserForm(forms.ModelForm):
	class Meta:
		model=Details
		fields = ["email","pasw"]
		widgets={
		"email":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Email Id"
			}),
		"pasw":forms.PasswordInput(attrs={
			"placeholder":"Password",
	        "class":"form-control my-2"				    
            }),
		}
class Std_det(forms.ModelForm):
	class Meta:
		model=Student_det
		fields = ["email","f_name","l_name", "ph_no", "r_no", "gender", "dob", "ft_name", "mt_name"]
		widgets = {
		"email":forms.TextInput(attrs={
			"class":"form-control my-3",
			"placeholder":"Email Id"
			}),
        "f_name": forms.TextInput(attrs={
        	"class":"form-control my-3",
            "placeholder": "First Name"
        }),
	    "l_name": forms.TextInput(attrs={
	    	"class":"form-control my-3",
            "placeholder": "Last Name"
        }),
        "ph_no": forms.TextInput(attrs={
        	"class":"form-control my-3",
            "placeholder": "Phone Number"
        }),
        "r_no": forms.TextInput(attrs={
        	"class":"form-control my-3",
            "placeholder": "Roll Number"
        }),
        "gender": forms.Select(attrs={
        	"class":"form-control my-3",
            "placeholder": "Gender"
        }),
        "dob": forms.DateInput(attrs={
        	"class":"form-control my-3",
            "type": "date",
	        "placeholder": "DOB"
		    #"input_formats"=["%d-%m-%Y"]" not working!
		
        }),
        "ft_name": forms.TextInput(attrs={
        	"class":"form-control my-3",
            "placeholder": "Father Name"
        }),
        "mt_name": forms.TextInput(attrs={
        	"class":"form-control my-3",
            "placeholder": "Mother Name"
        })
    }
class Std_UserForm(forms.ModelForm):
	class Meta:
		model=Details
		fields = ["email","pasw"]
		widgets={
		"email":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Email Id"
			}),
		"pasw":forms.PasswordInput(attrs={
			"placeholder":"Password",
	        "class":"form-control my-2"				    
            }),
		}