from django.apps import AppConfig


class ResumebuilderConfig(AppConfig):
    name = 'resumebuilder'
