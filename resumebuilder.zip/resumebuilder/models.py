from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
# Create your models here.
class Details(models.Model):
    email = models.CharField(max_length=30,unique=True)
    pasw = models.CharField(max_length=20)
class Fee_det(models.Model):
    term = models.CharField(max_length=30)
    email = models.CharField(max_length=30)
    Fee_type =  models.CharField(max_length=30)
    status = models.IntegerField()
    bal = models.IntegerField()
    date = models.CharField(max_length=10)
    time = models.CharField(max_length=10)
    fee_paid = models.IntegerField()
    transac_id = models.CharField(max_length=13)
    process = models.CharField(max_length=50)
class Student_det(models.Model):
    email = models.CharField(max_length=30,unique=True)
    f_name = models.CharField(max_length=25)
    l_name = models.CharField(max_length=25)
    ph_no = models.CharField(max_length=11)
    r_no = models.CharField(max_length=20)
    t = [
        ('select' , 'Select gender'),
        ('Male','Male'),
        ('Female','Female'),
        ('Other','Other'),
    ]

   #  nation = models.CharField(max_length=10)######

    gender = models.CharField(max_length=10,choices=t,default='Select gender')
    course = models.CharField(max_length=10)
    branch = models.CharField(max_length=20)
    dob = models.CharField(max_length=10)
    ft_name = models.CharField(max_length=40)
    mt_name = models.CharField(max_length=40)
    country = models.CharField(max_length=40)
    state = models.CharField(max_length=40)
    city = models.CharField(max_length=40)
    pasw = models.CharField(max_length=20)
    
class Bus_payment(models.Model):
    orj_id = models.IntegerField(unique=True)

    country = models.CharField(max_length=40)
    state = models.CharField(max_length=40)
    city = models.CharField(max_length=40)
    city = models.CharField(max_length=40)
    route =models.CharField(max_length=20)
    bus_no = models.CharField(max_length=10)
    bus_stop = models.CharField(max_length=20)
    time = models.CharField(max_length=20)
    date = models.CharField(max_length=20)
    rec_id = models.IntegerField()
class Room(models.Model):
    email1 = models.CharField(max_length=30)
    email2 = models.CharField(max_length=30)
    email3 = models.CharField(max_length=30)
    email4 = models.CharField(max_length=30)
    email5 = models.CharField(max_length=30)
    room_number = models.IntegerField()
    tower_num=models.IntegerField()
    floor_num=models.IntegerField()
    room_type=models.CharField(max_length=10) 
    sharing_type=models.IntegerField()
    occupied = models.IntegerField(default=0)
    fee=models.IntegerField(default=0)
    @property
    def vacancies(self):
        return self.sharing_type - self.occupied
class Table(models.Model):
    subj_code = models.CharField(max_length=30)
    pasw = models.CharField(max_length=30)
    p1 = models.CharField(max_length=10,default="-1,-1")
    p2 = models.CharField(max_length=10,default="-1,-1")
    p3 = models.CharField(max_length=10,default="-1,-1")

    name = models.CharField(max_length=40)
    user_id = models.CharField(max_length=30)
    pasword = models.CharField(max_length = 20)
    subj_name = models.CharField(max_length = 40)

class Store_att(models.Model):
    date = models.CharField(max_length=20)
    time = models.CharField(max_length=20)
    orj_id = models.IntegerField()
    subj_code = models.CharField(max_length=30)
class Marks(models.Model):
    subj_code = models.CharField(max_length=30)
    email = models.CharField(max_length=30)
    cla1 = models.IntegerField(validators=[ MaxValueValidator(5),MinValueValidator(0)])
    cla2 = models.IntegerField(validators=[ MaxValueValidator(10),MinValueValidator(0)])
    cla3 = models.IntegerField(validators=[ MaxValueValidator(10),MinValueValidator(0)])
    mid = models.IntegerField(validators=[ MaxValueValidator(25),MinValueValidator(0)])
    sem = models.IntegerField(validators=[ MaxValueValidator(100),MinValueValidator(0)])
class Quries(models.Model):
    subject = models.CharField(max_length=3000)
    text = models.CharField(max_length=3000)
    sender = models.CharField(max_length=50)
    reciever = models.CharField(max_length=50)
    time = models.CharField(max_length=30)
    date = models.CharField(max_length=30)
    enq_id = models.IntegerField()
class Announcement(models.Model):
    title = models.CharField(max_length=255)
    image = models.ImageField(upload_to='announcement_images/')  # Define the upload path for images
    body = models.TextField()

    def __str__(self):
        return self.title